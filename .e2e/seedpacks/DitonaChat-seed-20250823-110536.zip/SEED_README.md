# DitonaChat – Seed Pack (مختصر)
هذه الحزمة تحتوي الملفات الدنيا لفهم الواجهة وتخطيط شاشة الدردشة:
- `src/app/chat/page.tsx`: هيكل الصفحة (Stage/Video + قسم سفلي 50% + الرسائل + الشريط).
- `src/components/chat/Toolbar.tsx`: شريط الأدوات (Prev/Next + أيقونات) بقياس ذكي يحدّث `--tb-h`.
- `src/components/chat/ChatComposer.tsx`: محرر الرسائل الشفاف ويحدّث `--composer-h` + `--kb-pad`.
- `src/components/chat/ChatMessages.tsx`: عرض آخر الرسائل (latest/history) مع سحب ولون مختلف للمرسل/المستقبل.
- `src/components/chat/PeerHeader.tsx`: شريط علوي خفيف.
- `src/components/chat/LowerRightQuick.tsx`: زرا التبديل/التجميل أعلى يمين القسم السفلي.
- `src/app/globals.css`: متغيّرات CSS: `--tb-h`, `--composer-h`, `--kb-pad`, `--safe-b`، وأنماط الشفافية.
- إعدادات: `tailwind.config.js`, `postcss.config.js`, `tsconfig.json`, `package.json`.

ملاحظات سريعة:
- لا تشمل `node_modules` ولا `.next`. تشغيل التطوير: `pnpm exec next dev -p 3001`.
- واجهة الجوال أولًا؛ القسم السفلي ~50% من الارتفاع، مع حواف آمنة (safe-area).
