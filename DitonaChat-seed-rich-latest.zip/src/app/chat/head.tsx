export default function Head() {
  return (
    <>
      <meta
        name="tw-keep"
        content="grid-rows-[minmax(0,1fr)_minmax(0,1fr)_auto_auto] h-[100dvh] info@ditonachat.com"
      />
    </>
  );
}
