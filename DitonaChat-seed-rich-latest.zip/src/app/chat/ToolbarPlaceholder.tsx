"use client";
export default function ToolbarPlaceholder() {
  return null;
}
