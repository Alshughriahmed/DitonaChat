'use client';
import React from 'react';
export default function ClientShell({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
