export default function Privacy(){
  return <main style={{minHeight:"100dvh", padding:"40px", color:"#fff", background:"#0b0b12"}}>
    <h1 style={{fontSize:28, fontWeight:900, marginBottom:16}}>Privacy Policy</h1>
    <p style={{opacity:.9}}>Draft privacy…</p>
  </main>;
}
